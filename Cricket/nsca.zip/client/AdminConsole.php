<?php
include 'includes/components/header.php'
?>

    test datadffdsfsdfsdfsdfsdf

<?php
include 'includes/components/footer.php'
?>