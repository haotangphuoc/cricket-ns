<?php
include_once "../db/database.php";
include_once "../db/dbFunctions.php";
$conn = OpenCon();

$title = "Edit Sub Committees";
include "../includes/components/adminHeader.php";

?>

    <div class="col-7 offset-2">

    </div>

<?php

include "../includes/components/footer.php";