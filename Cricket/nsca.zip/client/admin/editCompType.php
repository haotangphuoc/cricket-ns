<?php
include_once "../db/database.php";
include_once "../db/dbFunctions.php";

?>


<?php

$title = "Edit Competition Types";
include "../includes/components/adminHeader.php";

?>



<?php

include "../includes/components/footer.php";